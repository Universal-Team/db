function preLoadImages(imgList)
{
	for(var i=0; i<imgList.length; ++i)
	{
		var img = new Image();
		img.src = imgList[i];
	}
}

function swapImg(id, src)
{
	var el = document.getElementById(id);
	if(!el)
		return;
	el.src = src;
}

function init()
{
	var images = 
	[
		"blue_buttons_r1_c1.png",
		"blue_buttons_r1_c4.png",
		"blue_buttons_r1_c5.png",
		"blue_buttons_r1_c6.png",
		"blue_buttons_r1_c9.png"
	];
	
	preLoadImages(images);
}